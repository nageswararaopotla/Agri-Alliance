import urequests
import machine
import network
from time import sleep

ssid = "agriwheel"
password = "123456789"

field1 = 42
api_key = "1ICUBQBKJU3I6JFJ"

def connect():
    station = network.WLAN(network.STA_IF)
    if station.isconnected() == True:
        print("Already connected")
        return
    station.active(True)
    station.connect(ssid,password)
    while station.isconnected()==False:
        pass
    print("connection successful")
    print(station.ifconfig())

def send_to_thingspeak(field1, api_key):
    url = "https://api.thingspeak.com/update?api_key=" + api_key + "&field1=" + str(field1)
    response = urequests.get(url)
    response.close()

connect()
while True:
    send_to_thingspeak(field1, api_key)
    sleep(2)
    print("suceesfully uploaded")
    field1=field1-10
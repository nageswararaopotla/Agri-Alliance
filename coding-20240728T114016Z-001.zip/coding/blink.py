import machine
from machine import ADC
import time
water = ADC(0)
inlet = machine.Pin(5,machine.Pin.OUT)
def do_connect():
    ssid = "agriwheel"
    password = "123456789"
    station = network.WLAN(network.STA_IF)
    if station.isconnected() == True:
        print("Already connected")
        return
    station.active(True)
    station.connect(ssid,password)
    while station.isconnected()==False:
        pass
    print("connection successful")
    print(station.ifconfig())
def getwl():
    wl = water.read()
    return wl
while True:
    inlet.value(1)
    print(1)
    time.sleep(10)
    inlet.value(0)
    time.sleep(10)
    print(0)
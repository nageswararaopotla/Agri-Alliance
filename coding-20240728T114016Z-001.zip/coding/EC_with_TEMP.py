from machine import ADC, Pin
import time

# EC sensor connected to ADC pin 0
ec_sensor = ADC(Pin(0))

# Temperature sensor connected to ADC pin 1
temp_sensor = ADC(Pin(1))

# Get EC sensor value
def get_ec_value():
    raw_value = ec_sensor.read()
    # Convert raw value to EC using a conversion formula specific to your EC sensor
    ec_value = raw_value * 0.001
    return ec_value

# Get temperature value from the temperature sensor
def get_temperature_value():
    raw_value = temp_sensor.read()
    # Convert raw value to temperature using a conversion formula specific to your temperature sensor
    temperature = raw_value * 0.001
    return temperature

while True:
    ec_value = get_ec_value()
    temperature = get_temperature_value()
    # Correct the EC value for the effect of temperature on the EC measurement using a temperature compensation formula
    ec_value = ec_value / (1.0 + 0.01 * (temperature - 25.0))
    # Print the corrected EC value and the temperature value on the serial monitor
    print("EC value:", ec_value, "ms/cm")
    print("Temperature:", temperature, "C")
    time.sleep(1)

import machine
from machine import Pin
from machine import ADC
import time
from time import sleep

waterLevel = ADC(0)

while True:
    waterLevel_value = waterLevel.read()
    if(waterLevel_value<=100):
        print(waterLevel_value,"Empty")
    elif(waterLevel_value>100 and waterLevel_value<=300):
        print(waterLevel_value,"Low")
    elif(waterLevel_value>300 and waterLevel_value<=330):
        print(waterLevel_value,"Medium")
    elif(waterLevel_value>330):
        print(waterLevel_value,"High")
    sleep(2)

    
    



 

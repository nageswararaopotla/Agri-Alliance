#om
#sri
#om
"""
1) Smart irrigation(Water_level and soil_moisture)
2) At the starting stage Crop_recommendation (NPK,EC,TEMP)
3) Fertilizer recommendation (NPK,EC,TEMP)
"""
import urequests    
import network
import time
import machine
from machine import Pin
from machine import ADC
water_pin = ADC(0)#32
moisture_pin = ADC(0)#35
EC_pin = ADC(0)#34
TEMP_pin = ADC(0)#33
NPK_pin = ADC(0)#39
inlet_motor_pin = Pin(14,Pin.OUT)#12
inlet_motor = 0
outlet_motor = 0
#FUNCTIONS
def do_connect():
    sta_if = network.WLAN(network.STA_IF)
    if not sta_if.isconnected():
        print('connecting to network...')
        sta_if.active(True)
        sta_if.connect('Dhanush_maari', 'massraja')
        while not sta_if.isconnected():
            pass
    print('network config:', sta_if.ifconfig())
def get_water_level():
    sense_water=water_pin.read()
    return sense_water
def get_soil_moisture():
    sense_soil = moisture_pin.read()
    return sense_soil
def get_EC():
    sense_EC=EC_pin.read()
def get_NPK():
    sense_NPK=NPK_pin.read()
    return sense_NPK
def get_TEMP():
    sense_TEMP = TEMP_pin.read()
    return sense_TEMP
def get_type_of_crop():
    return "Paddy"
def post_sense(present_water_level,present_soil_moisture,present_EC,present_TEMP,N,P,K,device_id,humidity,present_PH):
    url = 'https://sensesemi.in/api/arka/sensorDataUpdate.php'
    myobj = {
        "temperature": present_TEMP,
        "humidity": humidity,
        "ph_value": present_PH,
        "n_value": N,
        "p_value": P,
        "k_value": K,
        "device_id" :device_id,
        "water_level":present_water_level,
        "soil_moisture":present_soil_moisture,
        "ec":present_EC
    }
    x = urequests.post(url, json = myobj)
    print(x.text)
def get_sense():
    url2="https://awheel.blob.core.windows.net/project/backgroundData.json"
    res = urequests.get(url2,payload)
    print(res.text)
def get_crop_period():
    return "Short"
while True :
    do_connect()
    #getting time and date
    t = list(time.localtime())
    #hour =
    #minute =
    device_id = "DEVICE01"
    #Getting Sensor values
    present_water_level = get_water_level()
    present_soil_moisture = get_soil_moisture()
    present_EC = get_EC()
    present_TEMP = get_TEMP()
    present_PH = 7;
    N=0
    P=0
    K=0
    humidity=60
    #UPLOADING SENSOR DATA TO CLOUD - *DATABASE_3*** - FIELD_DATABASE (USING DEVICE ID)
    #WHICH DATA ? -->TIME,WATER_LEVEL,SOIL_MOISTURE,EC,NPK,TEMP
    post_sense(present_water_level,present_soil_moisture,present_EC,present_TEMP,N,P,K,device_id,humidity,present_PH)
    #*****----------------------------*******
    #RETREIVING REQUIRED DATA FOR IRRIGATION - **DATABASE_2** - CROP_DATABASE (USING DEVICE ID)
    crop_period = get_crop_period()
    days = get_crop_date()
    date = int(t[2])
    month = int(t[1])
    year =  int(t[0])
    no_irrgations_completed = get_number
    #WHICH DATA ? --> TYPE_OF_CROP
    type_of_crop = get_type_of_crop()
    #*****----------------------------*******
    #RETREIVING REQUIRED DATA FROM IRRIGATION - **DATABASE_1** - THRESHOLD_DATABASE(USING TYPE OF CROP)
    #WHICH DATA ? --> THRESHOLD VALUES OF NPK,EC,TEMP,WATER_LEVEL,SOIL_MOISTURE
    threshold = get_sensor_data()
    Threshold_water_level = threshold[5]
    Threshold_soil_mositure=threshold[6]
    #
    #conditioning
    if(type_of_crop=="Paddy"):
        print("paddy crop is detected")
        control_water=1
        while control_water :
            if(present_water_level<threshold_water_level):
                inlet_motor_in.on()
                time.sleep(10)
            else:
                control_water=0
        control_water=1
    else:
        print("others")
        control_soil=1
        while control_soil :
            if(present_water_level<threshold_water_level):
                inlet_motor_in.on()
                time.sleep(10)
            else:
                control_soil=0
    control_soil=1
    time.sleep(60)

